﻿using AspnetRun.Web.ViewModels.Base;

namespace AspnetRun.Web.ViewModels
{
    public class CategoryViewModel : BaseViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageName { get; set; }
    }
}
