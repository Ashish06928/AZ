﻿using AspnetRun.Application.Models;
using AspnetRun.Web.ViewModels;
using AutoMapper;

namespace AspnetRun.Web.Mapper
{
    public class AspnetRunProfile : Profile
    {
        public AspnetRunProfile()
        {
            CreateMap<ProductModel, ProductViewModel>().ReverseMap();
            CreateMap<CategoryModel, CategoryViewModel>().ReverseMap();
            CreateMap<CartModel, CartViewModel>().ReverseMap();
            CreateMap<CartItemModel, CartItemViewModel>().ReverseMap();
            CreateMap<OrderModel, OrderViewModel>().ReverseMap();
            CreateMap<AddressModel, AddressViewRequired>().ReverseMap();
            CreateMap<OrderItemModel, OrderItemView>().ReverseMap();
            CreateMap<AddressModel, AddressView>().ReverseMap();
        }
    }
}
