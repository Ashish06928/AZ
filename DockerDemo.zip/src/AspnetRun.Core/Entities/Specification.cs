﻿using AspnetRun.Core.Entities.Base;

namespace AspnetRun.Core.Entities
{
    public class Specification : Entity
    {        
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
