﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AspnetRun.Core.Configuration
{
    public class AspnetRunSettings
    {
        public string ConnectionString { get; set; }
    }
}
