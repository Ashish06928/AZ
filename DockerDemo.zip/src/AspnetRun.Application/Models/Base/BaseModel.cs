﻿namespace AspnetRun.Application.Models.Base
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
